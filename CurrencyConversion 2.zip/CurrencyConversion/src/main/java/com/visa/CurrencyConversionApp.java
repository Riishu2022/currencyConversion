package com.visa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurrencyConversionApp {

  /**
   * Simply start up Spring
   */
  public static void main(String[] args) {
    SpringApplication.run(CurrencyConversionApp.class);
  }
}
