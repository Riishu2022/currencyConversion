package com.visa.stepdefinitions;

import static org.testng.Assert.assertEquals;

import io.cucumber.java.en.Given;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Step definition class for ecm info backfill feature.
 */
public class CurrencyConversionStepDefinitions {


  @Given("^i invoke and validate api for currency \\\"([^\\\"]*)\\\" to \\\"([^\\\"]*)\\\" for \\\"([^\\\"]*)\\\" units$")
  public void iInvokeApi(String fromCurrency, String toCurrency, int units) throws Exception {
    String outputResponse = getConvertedValue(fromCurrency, toCurrency, units);
    int rateOfExchange = 0;
    if (fromCurrency.equalsIgnoreCase("USD") && toCurrency.equalsIgnoreCase("INR")) {
      rateOfExchange = 72;
    } else {
      rateOfExchange = 1;
    }
    assertEquals(String.valueOf(rateOfExchange * units), outputResponse);
  }

  private String getConvertedValue(String fromCurrency, String toCurrency, int units) {
    String outputResponse = null;
    try {

      StringBuilder urlBuilder = new StringBuilder().append("http://localhost:8080/convert/?")
          .append("fromCurrency=" + fromCurrency)
          .append("&toCurrency=" + toCurrency)
          .append("&units=" + units);
      URL url = new URL(urlBuilder.toString());
      HttpURLConnection conn = (HttpURLConnection) url.openConnection();
      conn.setRequestMethod("GET");
      conn.setRequestProperty("Accept", "application/json");

      if (conn.getResponseCode() != 200) {
        throw new RuntimeException("Failed : HTTP error code : "
            + conn.getResponseCode());
      }
      BufferedReader br = new BufferedReader(new InputStreamReader(
          (conn.getInputStream())));
      String output;
      while ((output = br.readLine()) != null) {
        outputResponse = output;
      }
      conn.disconnect();
    } catch (Exception e) {
      e.printStackTrace();
    }
    return outputResponse;
  }
}
