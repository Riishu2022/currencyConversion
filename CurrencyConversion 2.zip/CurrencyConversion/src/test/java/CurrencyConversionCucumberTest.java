import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.DataProvider;

@CucumberOptions(features = {"src/test/resources/features"},
    glue = {"com.visa.stepdefinitions"},tags = "@currencyConversion",
    plugin = {"pretty", "html:target/cucumber-reports/CurrencyConversionCucumberTestReport.html",
        "json:target/cucumber-reports/CurrencyConversionCucumberTestReport.json",
        "rerun:target/cucumber-reports/CurrencyConversionCucumberRerun.txt"}, monochrome = true)

/**
 * Class for running cucumber tests.
 */
public class CurrencyConversionCucumberTest extends AbstractTestNGCucumberTests {

  /**
   * Returns two dimensional array of {@link Object}s for the scenarios
   *
   * @return a two dimensional array of scenarios features.
   */
  @Override
  @DataProvider
  public Object[][] scenarios() {
    return super.scenarios();
  }
}
