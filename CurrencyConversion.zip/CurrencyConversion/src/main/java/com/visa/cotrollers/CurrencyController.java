package com.visa.cotrollers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CurrencyController {


  @GetMapping(value = "/convert/")
  public String convertCurrency(
      @RequestParam(value = "fromCurrency", required = false) String fromCurrency,
      @RequestParam(value = "toCurrency", required = false) String toCurrency,
      @RequestParam(value = "units") String units) {
    if (fromCurrency.equalsIgnoreCase("USD") && toCurrency.equalsIgnoreCase("INR")) {
      return String.valueOf(72 * Integer.valueOf(units));
    } else {
      return String.valueOf(Integer.valueOf(units));
    }
  }

}